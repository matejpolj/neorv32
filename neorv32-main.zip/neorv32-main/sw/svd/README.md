# NEORV32 System View Description (SVD) File

Manually created from `sw/lib/include/neorv32.h`.

* Format: CMSIS-SVD
* Copyright by ARM Ltd, Apache-2.0 License 
* Documentation:
   * https://www.keil.com/pack/doc/CMSIS/SVD/html/index.html
   * https://github.com/ARM-software/CMSIS
   * https://github.com/ARM-software/CMSIS_5
